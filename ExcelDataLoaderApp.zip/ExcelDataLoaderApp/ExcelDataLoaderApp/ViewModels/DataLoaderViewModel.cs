﻿using DataLoader.DataAccess;
using DataLoader.DataAccess.Interface;
using ExcelDataLoaderApp.Commands;
using Microsoft.Win32;
using System.Data;
using System.Windows.Input;

namespace ExcelDataLoaderApp.ViewModels
{
    public class DataLoaderViewModel : ViewModelBase
    {
        public ICommand BrowseCommand { get; private set; }
        public ICommand UploadCommand { get; private set; }
        public ICommand ViewCommand { get; private set; }

        public DataTable CommodityList { get; set; }
        public bool IsDataImportedSuccessfully { get; set; }

        private string _filePath;
        public string FilePath
        {
            set
            {
                _filePath = value;
                OnPropertyChanged();
            }
            get { return _filePath; }
        }

        public DataLoaderViewModel()
        {
            BrowseCommand = new DelegateCommand(OnBrowseExcelData, CanBrowse);
            UploadCommand = new DelegateCommand(OnUploadExcelData, CanUpload);
            ViewCommand = new DelegateCommand(OnViewData, CanViewData);
        }

        private bool CanViewData()
        {
            return IsDataImportedSuccessfully ? true : false;
        }

        private void OnViewData()
        {
            CommodityProfile view = new CommodityProfile();
            view.Show();

            App.Current.MainWindow.Close();
            App.Current.MainWindow = view;
        }

        private bool CanUpload()
        {
            if (string.IsNullOrEmpty(FilePath))
                return false;

            return true;
        }

        private void OnUploadExcelData()
        {
            ILoaderRepository repo = new LoaderRepository();
            IsDataImportedSuccessfully = repo.IsDataSuccessfullyInserted(FilePath);
        }

        private bool CanBrowse()
        {
            return true;
        }

        private void OnBrowseExcelData()
        {
            OpenFileDialog od = new OpenFileDialog();
            od.Filter = "Excel|*.xls;*.xlsx;";

            bool? result = od.ShowDialog();

            if (result == true)
            {
                FilePath = od.FileName.ToString();
            }

        }
    }
}
