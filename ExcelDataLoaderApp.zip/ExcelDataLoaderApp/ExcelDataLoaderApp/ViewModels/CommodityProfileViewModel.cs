﻿using DataLoader.DataAccess;
using DataLoader.DataAccess.Interface;
using DataLoader.DataAccess.ModelContext;
using DataLoader.Models;
using ExcelDataLoaderApp.Commands;
using ExcelDataLoaderApp.Extensions;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace ExcelDataLoaderApp.ViewModels
{
    public class CommodityProfileViewModel : ViewModelBase
    {
        public ICommand SearchCommand { get; private set; }
        public ICommand ResetCommand { get; private set; }
        public ICommand CloseCommand { get; private set; }

        ICommodityRepository commodityRepository;

        private ObservableCollection<Commodity> _commodityList;
        public ObservableCollection<Commodity> CommodityList
        {
            set
            {
                _commodityList = value;
                OnPropertyChanged();
            }
            get { return _commodityList; }
        }
        

        private DateTime _selectedDate;
        public DateTime SelectedDate
        {
            set
            {
                _selectedDate = value;
                OnPropertyChanged();
            }
            get { return _selectedDate; }
        }

        private string _code;
        public string Code
        {
            set
            {
                _code = value;
                OnPropertyChanged();
            }
            get { return _code; }
        }

        public CommodityProfileViewModel()
        {
            SearchCommand = new DelegateCommand(OnSearchCommodity, CanSearch);
            ResetCommand = new DelegateCommand(OnResetSearchCriteria, CanClearSearch);
            CloseCommand = new DelegateCommand(OnCloseForm, CanClose);

            CommodityList = new ObservableCollection<Commodity>();
            commodityRepository = new CommodityRepository(new CommodityContext());
            SelectedDate = DateTime.Today;

            LoadData();
        }

        private bool CanClose()
        {
            return true;
        }

        private void OnCloseForm()
        {
            App.Current.MainWindow.Close();
        }

        private bool CanClearSearch()
        {
            if (!string.IsNullOrEmpty(Code) && !string.IsNullOrEmpty(SelectedDate.ToString()))
                return true;

            return false;
        }

        private void OnResetSearchCriteria()
        {
            Code = string.Empty;
            SelectedDate = DateTime.Today;
            LoadData();
        }

        private void LoadData()
        {
            CommodityList.Clear();
            var allCommodities = commodityRepository.GetAllCommodity().ToList();
            CommodityList = allCommodities.ToObservableCollection();
        }

        private bool CanSearch()
        {
            if (CommodityList != null && CommodityList.Count > 0 && !string.IsNullOrEmpty(Code)
                && !string.IsNullOrEmpty(SelectedDate.ToString()))
                return true;

            return false;
        }

        private void OnSearchCommodity()
        {
            if (!string.IsNullOrEmpty(Code) && !string.IsNullOrEmpty(SelectedDate.ToString()))
            {
                Commodity result = commodityRepository.GetCommodityByCodeAndValidDate(Code, SelectedDate);

                if (result != null)
                {
                    CommodityList.Clear();
                    CommodityList.Add(result);
                }
                else
                {
                    MessageBox.Show("Search does not match. Please check the search criteria.", "Search Unsuccessful", MessageBoxButton.OK, MessageBoxImage.Information);
                }

            }            
        }
    }
}
