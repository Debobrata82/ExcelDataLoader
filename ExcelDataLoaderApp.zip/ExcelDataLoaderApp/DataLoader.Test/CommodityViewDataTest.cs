﻿using ExcelDataLoaderApp.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Globalization;

namespace DataLoader.Test
{
    /// <summary>
    /// Test to verify the data that is inserted in DB with the data that is being shown in UI
    /// </summary>
    [TestClass]
    public class CommodityViewDataTest
    {
        CommodityProfileViewModel profileViewModel;

        [TestInitialize]
        public void Initialize()
        {
            profileViewModel = new CommodityProfileViewModel();
        }

        [TestMethod]
        public void CommodityProfileDataTest()
        {
            Assert.IsTrue(profileViewModel.CommodityList != null);

            //Commodity list data count will be > 0
            Assert.IsFalse(profileViewModel.CommodityList.Count == 0);

            //Commodity list data count will be 5
            Assert.IsTrue(profileViewModel.CommodityList.Count == 5);

        }

        [TestMethod]
        public void SearchCriteriaTest()
        {
            // Search button is disabled
            Assert.IsFalse(profileViewModel.SearchCommand.CanExecute(null));

            profileViewModel.Code = "BRN";
            profileViewModel.SelectedDate = DateTime.ParseExact("01/01/2008", "dd/MM/yyyy", CultureInfo.InvariantCulture);

            // Search button is enabled
            Assert.IsTrue(profileViewModel.SearchCommand.CanExecute(null));

            profileViewModel.SearchCommand.Execute(null);

            //Commodity list data count will be 1
            Assert.IsTrue(profileViewModel.CommodityList.Count == 1);
        }

    }
}
