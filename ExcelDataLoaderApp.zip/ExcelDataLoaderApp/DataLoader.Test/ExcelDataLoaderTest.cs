﻿using System;
using ExcelDataLoaderApp.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DataLoader.Test
{
    /// <summary>
    /// Test to verify the insertion of data from excel to SQL DB.
    /// </summary>
    [TestClass]
    public class ExcelDataLoaderTest
    {
        [TestMethod]
        public void ExcelDataLoadTest()
        {
            DataLoaderViewModel dlViewModel = new DataLoaderViewModel();
            dlViewModel.FilePath = @"D:\Work\Excel Data Loader\ExcelDataLoaderApp\Chapter 5.xlsx";

            Assert.IsTrue(dlViewModel.UploadCommand.CanExecute(null));

            // Execute the Upload button to load the excel data in SQL DB
            dlViewModel.UploadCommand.Execute(null);

            Assert.IsTrue(dlViewModel.IsDataImportedSuccessfully);

            // If Upload is successful then View button will be enabled
            Assert.IsTrue(dlViewModel.ViewCommand.CanExecute(null));
        }
    }
}
