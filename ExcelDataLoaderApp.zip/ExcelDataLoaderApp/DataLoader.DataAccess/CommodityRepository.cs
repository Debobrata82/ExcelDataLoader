﻿using DataLoader.DataAccess.Interface;
using DataLoader.DataAccess.ModelContext;
using DataLoader.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DataLoader.DataAccess
{
    public class CommodityRepository : ICommodityRepository
    {
        private readonly CommodityContext _context;

        public CommodityRepository(CommodityContext context)
        {
            _context = context;
        }

        public void AddCommodity(Commodity commodityEntity)
        {
            if (commodityEntity != null)
            {
                _context.Commodities.Add(commodityEntity);
                _context.SaveChanges();
            }
        }

        public void DeleteCommodity(int commodityId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Commodity> GetAllCommodity()
        {
            return _context.Commodities.ToList();
        }

        public Commodity GetCommodityByCodeAndValidDate(string commodityCode, DateTime validDate)
        {
            return _context.Commodities.Where(x => x.CommodityCode == commodityCode && x.ValidFrom == validDate).FirstOrDefault();
        }

        public int UpdateCommodity(Commodity commodityEntity)
        {
            throw new NotImplementedException();
        }
    }
}
