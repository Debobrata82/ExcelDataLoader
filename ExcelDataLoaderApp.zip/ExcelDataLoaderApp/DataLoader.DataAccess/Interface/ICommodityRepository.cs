﻿using DataLoader.Models;
using System;
using System.Collections.Generic;

namespace DataLoader.DataAccess.Interface
{
    public interface ICommodityRepository
    {
        IEnumerable<Commodity> GetAllCommodity();
        Commodity GetCommodityByCodeAndValidDate(string commodityCode, DateTime validDate);
        void AddCommodity(Commodity commodityEntity);
        int UpdateCommodity(Commodity commodityEntity);
        void DeleteCommodity(int commodityId);
    }
}
