﻿namespace DataLoader.DataAccess.Interface
{
    public interface ILoaderRepository
    {
        bool IsDataSuccessfullyInserted(string path);
    }
}
