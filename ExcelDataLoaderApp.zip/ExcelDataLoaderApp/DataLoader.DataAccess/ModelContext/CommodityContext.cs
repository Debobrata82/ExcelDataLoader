﻿using DataLoader.Models;
using System.Configuration;
using System.Data.Entity;

namespace DataLoader.DataAccess.ModelContext
{
    public class CommodityContext : DbContext
    {
        public CommodityContext() : base(ConfigurationManager.ConnectionStrings["CommodityProfile"].ConnectionString) { }
        public DbSet<Commodity> Commodities
        {
            get;
            set;
        }
    }
}
