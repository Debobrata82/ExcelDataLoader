﻿using DataLoader.DataAccess.Interface;
using System;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Windows;

namespace DataLoader.DataAccess
{
    public class LoaderRepository : ILoaderRepository
    {
        public bool IsDataSuccessfullyInserted(string path)
        {
            string constr = string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=""Excel 12.0 Xml;HDR=YES;""", path);
            DataTable Exceldt;

            try
            {
                using (OleDbConnection excelConn = new OleDbConnection(constr))
                {
                    string Query = string.Format("Select * FROM [{0}]", "Sheet1$");
                    using (OleDbCommand Ecom = new OleDbCommand(Query, excelConn))
                    {
                        excelConn.Open();

                        DataSet ds = new DataSet();
                        using (OleDbDataAdapter oda = new OleDbDataAdapter(Query, excelConn))
                        {
                            excelConn.Close();
                            oda.Fill(ds);
                            Exceldt = ds.Tables[0];
                            Exceldt.AcceptChanges();
                        }
                    }

                }

                //inserting Datatable Records to DataBase   
                using (SqlConnection sqlConnection = new SqlConnection())
                {
                    sqlConnection.ConnectionString = ConfigurationManager.ConnectionStrings["CommodityProfile"].ConnectionString.Trim();

                    //creating object of SqlBulkCopy      
                    SqlBulkCopy objbulk = new SqlBulkCopy(sqlConnection);
                    //assigning Destination table name      
                    objbulk.DestinationTableName = "Commodity";
                    //Mapping Table column    
                    objbulk.ColumnMappings.Add("[Commodity Code]", "CommodityCode");
                    objbulk.ColumnMappings.Add("[Diminishing Balance Contract]", "DiminishingBalanceContract");
                    objbulk.ColumnMappings.Add("[Expiry Month Limit]", "ExpiryMonthLimit");
                    objbulk.ColumnMappings.Add("[All Month Limit]", "AllMonthLimit");
                    objbulk.ColumnMappings.Add("[Any One Month Limit]", "AnyOneMonthLimit");
                    objbulk.ColumnMappings.Add("[Valid From (dd/mm/yyyy)]", "ValidFrom");

                    sqlConnection.Open();

                    // Clears any existing records
                    using (SqlCommand command = new SqlCommand("DELETE FROM Commodity", sqlConnection))
                    {
                        command.ExecuteNonQuery();
                    }

                    objbulk.WriteToServer(Exceldt);

                    MessageBox.Show("Data has been Imported successfully.", "Imported", MessageBoxButton.OK, MessageBoxImage.Information);

                    return true;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(string.Format("Data has not been Imported due to :{0}", ex.Message), "Not Imported", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

        }
    }
}
