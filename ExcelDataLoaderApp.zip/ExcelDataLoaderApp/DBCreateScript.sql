USE MASTER

IF EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = 'CommodityDB')
DROP DATABASE CommodityDB
GO

CREATE DATABASE CommodityDB
GO

USE [CommodityDB]
GO  
SET ANSI_NULLS ON  
GO  
SET QUOTED_IDENTIFIER ON  
GO 

CREATE TABLE Commodity (
CommodityId INT NOT NULL IDENTITY PRIMARY KEY,
CommodityCode NVARCHAR(20) NOT NULL,
DiminishingBalanceContract VARCHAR(1) NOT NULL,
ExpiryMonthLimit DECIMAL(8,1) NOT NULL,
AllMonthLimit DECIMAL(8,1) NOT NULL,
AnyOneMonthLimit DECIMAL(8,1) NOT NULL,
ValidFrom DATE NOT NULL DEFAULT GETDATE()
)