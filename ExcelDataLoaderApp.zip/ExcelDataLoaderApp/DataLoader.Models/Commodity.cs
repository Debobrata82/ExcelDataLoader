﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataLoader.Models
{
    [Table("Commodity")]
    public class Commodity
    {
        [Key]
        public int CommodityId { get; set; }
        public string CommodityCode { get; set; }
        public string DiminishingBalanceContract { get; set; }
        public decimal ExpiryMonthLimit { get; set; }
        public decimal AllMonthLimit { get; set; }
        public decimal AnyOneMonthLimit { get; set; }
        public DateTime ValidFrom { get; set; }
    }
}
